# ระบบรับสมัครนักเรียนออนไลน์

เว็บไซต์รับสมัครนักเรียนออนไลน์ เชื่อมต่อกับ Google Sheets อัตโนมัติ

## วิธี Deploy ขึ้น GitHub Pages (ฟรี ไม่ต้องจ่ายเงิน)

### ขั้นตอนที่ 1 — สร้าง GitHub Repository
1. ไปที่ [github.com](https://github.com) → Sign in หรือสมัครสมาชิกฟรี
2. กดปุ่ม **"New"** (สีเขียว) เพื่อสร้าง repository ใหม่
3. ตั้งชื่อ repo เช่น `school-registration` (ชื่อนี้จะเป็นส่วนหนึ่งของ URL)
4. เลือก **Public** → กด **"Create repository"**

### ขั้นตอนที่ 2 — อัปโหลดไฟล์
1. ในหน้า repo ที่เพิ่งสร้าง กด **"uploading an existing file"**
2. ลากไฟล์ `index.html` มาวาง (ไฟล์นี้คือ student-registration-v13.html ที่เปลี่ยนชื่อแล้ว)
3. กด **"Commit changes"**

### ขั้นตอนที่ 3 — เปิด GitHub Pages
1. ไปที่ **Settings** → **Pages** (เมนูซ้าย)
2. Source: **Deploy from a branch**
3. Branch: **main** → folder: **/ (root)**
4. กด **Save**
5. รอ 1-2 นาที → URL จะปรากฏ รูปแบบ:
   ```
   https://[ชื่อ GitHub ของคุณ].github.io/school-registration/
   ```

### ขั้นตอนที่ 4 — เชื่อมกับ Google Apps Script
1. เปิดไฟล์ `index.html` ในเว็บไซต์
2. Login Admin → ⚙️ ตั้งค่า → วาง Web App URL → บันทึก

---
รหัสแอดมินเริ่มต้น: `admin` / `admin123`
